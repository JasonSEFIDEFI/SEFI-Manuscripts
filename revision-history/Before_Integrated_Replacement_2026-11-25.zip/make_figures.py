"""Deterministic vector figures for the manuscript. NumPy and ReportLab only."""
from pathlib import Path
import math,json
import numpy as np
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor
R=Path(__file__).resolve().parent;F=R/'figures';F.mkdir(exist_ok=True)
NAVY='#16334C';TEAL='#007E87';GOLD='#9D6E3B';GRAY='#69757F';LIGHT='#D9E1E5'
def text(c,x,y,s,size=10,color=NAVY,bold=False):c.setFillColor(HexColor(color));c.setFont('Helvetica-Bold' if bold else 'Helvetica',size);c.drawString(x,y,str(s))
def line(c,points,color=TEAL,width=1.5):
    c.setStrokeColor(HexColor(color));c.setLineWidth(width);p=c.beginPath();p.moveTo(*points[0])
    for x,y in points[1:]:p.lineTo(x,y)
    c.drawPath(p)
def arrow(c,x,y,z,w,color=GRAY):
    line(c,[(x,y),(z,w)],color,1);t=math.atan2(w-y,z-x);line(c,[(z-6*math.cos(t-.4),w-6*math.sin(t-.4)),(z,w),(z-6*math.cos(t+.4),w-6*math.sin(t+.4))],color,1)
def box(c,x,y,w,h,title,sub):
    c.setStrokeColor(HexColor(LIGHT));c.setFillColor(HexColor('#F5F8F9'));c.roundRect(x,y,w,h,4,stroke=1,fill=1);text(c,x+10,y+h-22,title,11,bold=True)
    for k,s in enumerate(sub):text(c,x+10,y+h-40-14*k,s,9,GRAY)
def chart(c,x,y,w,h,xmin,xmax,ymin,ymax,xlabel,ylabel):
    line(c,[(x,y+h),(x,y),(x+w,y)],GRAY,.7)
    for v in np.linspace(xmin,xmax,5):
        xx=x+(v-xmin)/(xmax-xmin)*w;line(c,[(xx,y-3),(xx,y)],GRAY,.7);text(c,xx-7,y-15,f'{v:g}',8,GRAY)
    for v in np.linspace(ymin,ymax,5):
        yy=y+(v-ymin)/(ymax-ymin)*h;line(c,[(x-3,yy),(x+w,yy)],LIGHT,.5);text(c,x-34,yy-3,f'{v:g}',8,GRAY)
    text(c,x+w*.22,y-32,xlabel,9);text(c,x,y+h+15,ylabel,9)
    return lambda a,b:(x+(a-xmin)/(xmax-xmin)*w,y+(b-ymin)/(ymax-ymin)*h)

c=canvas.Canvas(str(F/'model-structure.pdf'),pagesize=(620,250));c.setTitle('Single field and specified quantum realization')
box(c,10,140,175,88,'One complex scalar',['Action, current and energy','Constrained conjugate pair'])
box(c,223,140,175,88,'Internal field response',['Positive stiffness and modes','Specified local approximation'])
box(c,436,140,174,88,'Localized configuration',['Nonlinear profile equation','Numerical scalar benchmark'])
arrow(c,187,184,220,184);arrow(c,400,184,433,184)
box(c,10,15,175,82,'Coherent mode register',['Amplitudes and readout','Additional quantum assumptions'])
box(c,223,15,175,82,'Two controlled auxiliaries',['Forced oscillators, phase','Difference and companion'])
box(c,436,15,174,82,'Recovery criterion',['Equal residual states','Unknown coherence retained'])
arrow(c,187,56,220,56);arrow(c,400,56,433,56)
line(c,[(10,118),(610,118)],LIGHT,.8);text(c,15,108,'A physical mode/control correspondence between these descriptions must be specified.',9,GRAY)
c.save()

c=canvas.Canvas(str(F/'localization-spectrum.pdf'),pagesize=(620,260));c.setTitle('Local scalar profile and internal spectrum')
p=np.load(R/'numerical/radial-profile.npz');xy=chart(c,50,48,230,162,0,12,0,1.4,'radius r','(a) Scalar profile f(r)')
mask=p['r']<=12;line(c,[xy(float(x),float(y)) for x,y in zip(p['r'][mask],p['f'][mask])])
xy=chart(c,355,48,230,162,0,1,0,2,'coupling radius r','(b) Stiffness eigenvalues')
for sign,col in [(-1,TEAL),(0,GRAY),(1,GOLD)]:line(c,[xy(float(x),1+sign*float(x)) for x in np.linspace(0,.99,100)],col)
text(c,415,235,'Lower / double unit / upper branch',8,GRAY);c.save()

c=canvas.Canvas(str(F/'saddle-timing.pdf'),pagesize=(620,435));c.setTitle('Saddle design, companion coordinate and timing law')
def surface(cx,cy,kind):
    def proj(x,y,z):return cx+65*x-42*y,cy+20*x+28*y+70*z
    fun=(lambda x,y:.25*x*x-.15*y*y) if kind=='difference' else (lambda x,y:-2*np.sqrt(2)*.1-.25*x*x-.15*y*y)
    for v in np.linspace(-1,1,13):
        line(c,[proj(x,v,fun(x,v)) for x in np.linspace(-1,1,60)],TEAL if kind=='difference' else GOLD,.6)
        line(c,[proj(v,y,fun(v,y)) for y in np.linspace(-1,1,60)],TEAL if kind=='difference' else GOLD,.6)
text(c,30,410,'(a) Difference displacement',11,bold=True);text(c,335,410,'(b) Companion displacement',11,bold=True)
surface(160,325,'difference');surface(465,362,'companion');text(c,75,252,'hZ = alpha x^2 - beta y^2',9);text(c,365,252,'hB = -2 sqrt(2) J0/k - alpha x^2 - beta y^2',8)
text(c,155,233,'Design coordinates x, y in [-1, 1]; displacements dimensionless',8,GRAY)
xy=chart(c,65,57,515,145,0,.4,.9975,1,'timing offset delta t','(c) Entanglement fidelity')
for v in [.9975,.998125,.99875,.999375,1]:pass
xs=np.linspace(0,.4,250);ys=(1+np.exp(-.5*(.8*np.sin(xs))**2*.3**2))/2;line(c,[xy(float(x),float(y)) for x,y in zip(xs,ys)],TEAL,1.8)
data=json.loads((R/'numerical/model-verification.json').read_text())
for row in data['timing']:
    x,y=xy(row['delta'],(1+row['direct_kernel_real'])/2);c.setFillColor(HexColor(GOLD));c.circle(x,y,2.7,stroke=0,fill=1)
text(c,325,211,'Curve: exact law   Dots: direct Fock calculation',8,GRAY);c.save()
print('Generated three original vector figures.')
