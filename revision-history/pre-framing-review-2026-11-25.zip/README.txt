Conjugate Phase Geometry and Coherent Recovery
AIP Advances preparation | November 25, 2026

Compile Conjugate_Phase_Geometry_AIP_Advances.tex twice with pdfLaTeX (REVTeX 4.2). Keep figures/ beside the TeX file. Bibliography is embedded.

Source: JPA11232026/main.tex, matched to the user-named blind-review manuscript. Changes: removed electron--positron subtitle from visible title and PDF metadata; switched journal class option jmp to adv; updated date; added cmap for searchable text. Mathematical body, references, figures and qualifications are preserved. This is formatting preparation, not a new scientific validation.

The source archive includes figures, numerical scripts and saved outputs, requirements, and original source for provenance. No deletion, journal upload or submission was performed. The separate prior AIP preparation dated November 24 was not substituted for the requested manuscript.
