"""Add the exact manuscript-title card, without changing any narrated frames."""
from pathlib import Path
import subprocess,shutil,json,hashlib
R=Path(__file__).resolve().parent;B=R/'render';B.mkdir(exist_ok=True)
ff=shutil.which('ffmpeg') or r'C:\ffmpeg\ffmpeg-9.0.1-essentials_build\bin\ffmpeg.exe'
master=R/'SEFI-Graphical-Abstract-Master.mp4';marker=R/'opening.json'
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if marker.exists() and json.loads(marker.read_text()).get('final_sha256')==digest(master):raise SystemExit('Opening already present.')
intro=B/'opening.mp4'
subprocess.run([ff,'-v','error','-loop','1','-i',str(R/'highlight.jpg'),'-f','lavfi','-i','anullsrc=r=48000:cl=mono','-t','3','-vf','scale=1280:720','-r','24','-c:v','libx264','-threads','2','-preset','fast','-crf','18','-pix_fmt','yuv420p','-c:a','aac','-b:a','160k','-y',str(intro)],check=True)
lst=B/'opening-concat.txt';lst.write_text("file 'opening.mp4'\nfile '../SEFI-Graphical-Abstract-Master.mp4'\n",encoding='utf-8')
out=B/'with-opening.mp4'
title='SEFI: The Single Entity Field Interpretation — Formal Mathematical Construction'
subprocess.run([ff,'-v','error','-f','concat','-safe','0','-i',str(lst),'-c','copy','-metadata','title='+title,'-movflags','+faststart','-y',str(out)],check=True)
shutil.copyfile(out,master);assert master.stat().st_size<10_000_000
shutil.copyfile(master,R/'SEFI-Graphical-Abstract-Under-10MB.mp4')
t=json.loads((R/'timeline.json').read_text())
for e in t:e['start']+=3;e['end']+=3
t.insert(0,dict(scene=0,start=0,end=3,duration=3,source='highlight.jpg',note='Exact manuscript-title opening card'))
(R/'timeline.json').write_text(json.dumps(t,indent=2),encoding='utf-8')
marker.write_text(json.dumps(dict(final_sha256=digest(master),title=title,opening_seconds=3),indent=2),encoding='utf-8')
print('Exact-title opening added:',master.stat().st_size,'bytes',flush=True)
