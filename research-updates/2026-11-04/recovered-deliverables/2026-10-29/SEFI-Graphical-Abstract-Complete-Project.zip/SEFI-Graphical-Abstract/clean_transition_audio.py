"""Remove approach noises in the lead-ins of scenes 5, 7 and 9.
Video frames and timing are unchanged. Original recordings are retained.
"""
from pathlib import Path
import subprocess,json,shutil,hashlib
R=Path(__file__).resolve().parent;B=R/'render';B.mkdir(exist_ok=True)
ff=shutil.which('ffmpeg') or r'C:\ffmpeg\ffmpeg-9.0.1-essentials_build\bin\ffmpeg.exe'
timeline=json.loads((R/'timeline.json').read_text());trans=json.loads((R/'transcript.json').read_text())
windows=[];filters=[]
for scene in [5,7,9]:
    entry=next(e for e in timeline if e['scene']==scene)
    start=entry['start'];speech=start+trans[str(scene)][0]['start'];end=speech-.6
    windows.append(dict(scene=scene,start=start,end=end,first_speech=speech,fade_in_seconds=.12,speech_margin_seconds=.48))
    filters.append(f"volume='if(between(t,{start:.8f},{end:.8f}),0,if(between(t,{end:.8f},{end+.12:.8f}),(t-{end:.8f})/.12,1))':eval=frame")
master=R/'SEFI-Graphical-Abstract-Master.mp4';target=B/'clean-transitions.mp4';backup=B/'before-transition-cleanup.mp4'
if not backup.exists() or '--refresh-source' in __import__('sys').argv:shutil.copyfile(master,backup)
subprocess.run([ff,'-v','error','-i',str(backup),'-map','0:v:0','-map','0:a:0','-c:v','copy','-af',','.join(filters),'-c:a','aac','-b:a','160k','-movflags','+faststart','-y',str(target)],check=True)
assert target.stat().st_size<10_000_000
shutil.copyfile(target,master);shutil.copyfile(target,R/'SEFI-Graphical-Abstract-Under-10MB.mp4')
# Keep the standalone narration master consistent (it excludes the 3-second title card).
audio_filters=[]
for w in windows:
    a=w['start']-3;b=w['end']-3
    audio_filters.append(f"volume='if(between(t,{a:.8f},{b:.8f}),0,if(between(t,{b:.8f},{b+.12:.8f}),(t-{b:.8f})/.12,1))':eval=frame")
audio=R/'SEFI-Narration-Master.wav';original=B/'before-transition-cleanup.wav'
if not original.exists() or '--refresh-source' in __import__('sys').argv:shutil.copyfile(audio,original)
subprocess.run([ff,'-v','error','-i',str(original),'-af',','.join(audio_filters),'-c:a','pcm_s24le','-y',str(audio)],check=True)
(R/'audio-cleanup.json').write_text(json.dumps(dict(description='Mic-approach lead-ins muted in scenes 5, 7, 9; original speech and video timing retained.',windows=windows),indent=2),encoding='utf-8')
marker=R/'opening.json'
if marker.exists():
    data=json.loads(marker.read_text());data['final_sha256']=hashlib.sha256(master.read_bytes()).hexdigest();marker.write_text(json.dumps(data,indent=2),encoding='utf-8')
print(json.dumps(dict(bytes=master.stat().st_size,windows=windows),indent=2),flush=True)
