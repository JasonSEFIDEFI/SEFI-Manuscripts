"""Rebuild the narrated SEFI graphical abstract. Requires Python, Pillow, NumPy, FFmpeg.
All diagrams are analytic illustrations, not experimental data.
"""
from pathlib import Path
import math,json,subprocess,wave,shutil,hashlib,zipfile
import numpy as np
from PIL import Image,ImageDraw,ImageFont
R=Path(__file__).resolve().parent
FF=shutil.which('ffmpeg') or r'C:\ffmpeg\ffmpeg-9.0.1-essentials_build\bin\ffmpeg.exe'
W,H=1280,720
BG='#F5F3EE';INK='#12233A';TEAL='#087F89';VIOLET='#7160B6';MUTE='#5D6977';RULE='#D8DDE0'
def font(n,b=False):return ImageFont.truetype('C:/Windows/Fonts/'+('segoeuib.ttf' if b else 'segoeui.ttf'),n)
def txt(d,x,y,s,n=24,c=INK,b=False):
    f=ImageFont.truetype('C:/Windows/Fonts/seguisym.ttf',n) if any(ch in s for ch in '∝∇∫') else font(n,b)
    d.text((x,y),s,font=f,fill=c)
def arrow(d,a,b,c=TEAL,width=4):
    d.line([a,b],fill=c,width=width);t=math.atan2(b[1]-a[1],b[0]-a[0]);d.polygon([b,(b[0]-13*math.cos(t-.45),b[1]-13*math.sin(t-.45)),(b[0]-13*math.cos(t+.45),b[1]-13*math.sin(t+.45))],fill=c)
def poly(d,pts,c=TEAL,w=4):d.line(pts,fill=c,width=w,joint='curve')
def phase(d,cx=940,cy=350,r=150):
    d.line((cx-r-35,cy,cx+r+35,cy),fill=RULE,width=2);d.line((cx,cy-r-35,cx,cy+r+35),fill=RULE,width=2)
    for j,rr in enumerate([r,r-28]):
        col=[TEAL,VIOLET][j];pts=[(cx+rr*math.cos(t),cy+rr*math.sin(t)) for t in np.linspace(0,2*math.pi,240)];poly(d,pts,col,4)
        t=[-.7,2.2][j];s=[1,-1][j];p=(cx+rr*math.cos(t),cy+rr*math.sin(t));q=(cx+rr*math.cos(t+.16*s),cy+rr*math.sin(t+.16*s));arrow(d,p,q,col)
    txt(d,cx-r,cy+r+45,'INTERNAL PHASE SPACE',19,MUTE,True)
def curve(d,kind):
    x0,y0,x1,y1=755,490,1190,230
    d.line((x0,y1,x0,y0,x1,y0),fill=RULE,width=2)
    if kind=='profile':
        p=np.load(R/'radial-profile.npz'); rr=p['r']; f=p['f']; sel=rr<=12
        pts=[(x0+435*x/12,y0-230*y/max(f)) for x,y in zip(rr[sel],f[sel])];poly(d,pts)
        txt(d,815,540,'Localized scalar profile',23);txt(d,810,575,'Numerical benchmark • not particle data',17,MUTE)
    elif kind=='optics':
        pts=[(x0+435*x,y0-215*(math.cos(5*math.pi*x)**2)*math.exp(-((x-.5)/.55)**2)) for x in np.linspace(0,1,500)];poly(d,pts)
        txt(d,815,540,'Phase-sensitive intensity',23);txt(d,825,575,'Analytic illustration',18,MUTE)
    else:
        for k,c in [(3,TEAL),(4,VIOLET)]:
            pts=[(x0+435*x,y0-230*(1+3*x)**(-k)) for x in np.linspace(0,1,250)];poly(d,pts,c)
        txt(d,810,540,'Charge density  ∝  a⁻³',25,TEAL);txt(d,810,580,'Radiation energy  ∝  a⁻⁴',23,VIOLET)
def dna(d,cx=960,cy=350,scale=1):
    for shift,c in [(0,TEAL),(math.pi,VIOLET)]:
        pts=[(cx+110*scale*math.sin(u+shift),cy+u*19*scale) for u in np.linspace(-8,8,500)];poly(d,pts,c,5)
    for u in np.arange(-7.5,8,.7):d.line((cx+110*scale*math.sin(u),cy+u*19*scale,cx-110*scale*math.sin(u),cy+u*19*scale),fill=RULE,width=2)
    txt(d,cx-170,cy+190*scale,'IDEAL HELIX GEOMETRY',19,MUTE,True)
def detector(d):
    for j in range(7):
        pts=[(740+x,310+j*15+18*math.sin(x/45)) for x in range(410)];poly(d,pts,TEAL,2)
    d.rounded_rectangle((1030,225,1080,470),12,fill=INK)
    arrow(d,(1100,350),(1190,350),VIOLET);txt(d,860,535,'Field → coupling → readout',24)
def makecard(i,title,lines,kind,eq='',note=''):
    im=Image.new('RGB',(W,H),BG);d=ImageDraw.Draw(im)
    d.rectangle((0,0,W,7),fill=INK);d.rectangle((0,0,320,7),fill=TEAL)
    txt(d,60,38,'SEFI  /  SINGLE ENTITY FIELD INTERPRETATION',18,TEAL,True)
    txt(d,60,128,title,43,INK,True)
    for j,l in enumerate(lines):txt(d,64,228+j*43,l,25,MUTE)
    if eq:txt(d,64,435,eq,32,TEAL,True)
    if note:txt(d,64,510,note,20,MUTE)
    if kind=='phase':phase(d)
    elif kind in ['profile','optics','cosmo']:curve(d,kind)
    elif kind=='dna':dna(d)
    elif kind=='detector':detector(d)
    elif kind=='links':
        for j,(s,col) in enumerate([('PHOTONICS',TEAL),('DNA GEOMETRY',VIOLET),('COSMOLOGY',INK)]):
            yy=240+j*100;d.rounded_rectangle((755,yy,1190,yy+65),12,outline=col,width=2);txt(d,785,yy+15,s,24,col,True)
    d.line((60,636,1220,636),fill=RULE,width=2)
    txt(d,60,660,'JASON DURAN DUTTON  •  SEFI RESEARCH PROGRAM',17,MUTE)
    txt(d,1115,658,f'{i:02d} / 10',19,MUTE)
    (R/'cards').mkdir(exist_ok=True);im.save(R/'cards'/f'{i:02d}.png');return im
SPECS=[
 ('A geometric interpretation',['The Single Entity Field Interpretation','Geometric foundations and mappings','Following the GWFM construction'],'phase','','Jason Duran Dutton'),
 ('One shared field',['Two internal phase directions','A common field configuration','An internal orbit signature'],'phase','Φ(t) = exp(−iωJt) a','Physical temporal identification remains open'),
 ('From picture to equations',['State the assumptions','Specify the action and dynamics','Calculate a localized profile'],'profile','□Φ + U′(ρ)Φ = 0','A specified classical scalar realization'),
 ('Mathematical scope',['Conserved currents and energy','A reproducible local benchmark','Stability requires further analysis'],'profile','∇μ jμ = 0','Localization does not establish an electron'),
 ('Observation needs a rule',['A field is not a detector output','Trajectory and coupling matter','Define what is measured'],'detector','Rᴅ[Φ, g]','Energy concentration ≠ a detection event'),
 ('Phase and optical readout',['Complex mode amplitudes','Relative phase and recombination','Compare against established optics'],'optics','p₀ = cos²(α / 2)','Quantum encoding and recovery are extra tasks'),
 ('Optics as a benchmark',['Vary phase, compare readout','Use established optical predictions','Encoding, noise and recovery for QEC'],'optics','p₀ = cos²(α / 2)','Equal-arm, ideal coherent example'),
 ('A geometric DNA mapping',['Radius and pitch define a helix','Curvature and torsion are invariants','Test couplings against structures'],'dna','κ = R / (R² + b²)','A spatial phase parameter, not reversed time'),
 ('Fields in an expanding space',['Conserved current dilution','Energy also depends on pressure','Specify the gravitational dynamics'],'cosmo','a³ j⁰ = constant','Prescribed background ≠ a full gravity solution'),
 ('Calculate. Compare. Test.',['A language for human understanding','Vortex investigations and field work','Electron–positron derivation remains open'],'links','','github.com/JasonSEFIDEFI/Research')]
def highlight():
    im=Image.new('RGB',(1920,1080),BG);d=ImageDraw.Draw(im)
    d.rectangle((0,0,1920,10),fill=INK);d.rectangle((0,0,550,10),fill=TEAL)
    txt(d,90,62,'SEFI  /  GEOMETRIC FOUNDATIONS',27,TEAL,True)
    txt(d,86,140,'SEFI: The Single Entity Field',75,INK,True);txt(d,86,240,'Interpretation — Formal Mathematical Construction',55,INK,True)
    txt(d,92,345,'Shared field. Internal phase. Specified observation.',32,MUTE)
    for x in [90,540,990,1440]:d.rounded_rectangle((x,440,x+390,865),20,outline=RULE,width=2)
    for x,s in [(120,'PHASE STRUCTURE'),(570,'PHOTONICS'),(1020,'DNA GEOMETRY'),(1470,'EXPANSION')]:txt(d,x,470,s,23,TEAL,True)
    phase(d,285,650,95);dna(d,1185,650,.65)
    poly(d,[(570+330*x,765-180*math.cos(4*math.pi*x)**2*math.exp(-((x-.5)/.6)**2)) for x in np.linspace(0,1,350)],TEAL,4)
    txt(d,580,800,'Phase-sensitive readout',21,MUTE)
    for k,c in [(3,TEAL),(4,VIOLET)]:poly(d,[(1470+330*x,765-180*(1+3*x)**(-k)) for x in np.linspace(0,1,250)],c,5)
    txt(d,1470,800,'Charge density ∝ a⁻³',21,MUTE)
    txt(d,92,915,'Conditional mathematical mappings • particle identification remains open',27,MUTE)
    txt(d,92,1000,'JASON DURAN DUTTON  |  SEFI RESEARCH PROGRAM',23,INK,True)
    im.save(R/'highlight.jpg',quality=96,subsampling=0,dpi=(300,300));return im
if __name__=='__main__':
    for i,s in enumerate(SPECS,1):makecard(i,*s)
    highlight()
    if '--render' in __import__('sys').argv:
        build=R/'render';build.mkdir(exist_ok=True)
        transcript=json.loads((R/'transcript.json').read_text()); timeline=[];parts=[];cursor=0;rate=48000
        for i in range(1,11):
            p=build/f'audio-{i:02d}.wav'
            subprocess.run([FF,'-v','error','-i',str(R/'audio'/f'{i}.wav'),'-ar',str(rate),'-ac','1','-c:a','pcm_s16le','-y',str(p)],check=True)
            with wave.open(str(p)) as w:samples=np.frombuffer(w.readframes(w.getnframes()),np.int16).copy()
            # Preserve the entire recording, including consonants, breaths and natural tails.
            tail=.45 if i<10 else 3.0
            samples=np.concatenate([samples,np.zeros(round(tail*rate),np.int16)])
            duration=len(samples)/rate;frames=math.ceil(duration*24);pad=round(frames/24*rate)-len(samples)
            samples=np.pad(samples,(0,pad));duration=frames/24;parts.append(samples)
            timeline.append(dict(scene=i,start=cursor,end=cursor+duration,duration=duration,source=f'audio/{i}.wav',source_samples_preserved=True));cursor+=duration
        with wave.open(str(build/'narration.wav'),'wb') as w:
            w.setnchannels(1);w.setsampwidth(2);w.setframerate(rate);w.writeframes(np.concatenate(parts).tobytes())
        (R/'timeline.json').write_text(json.dumps(timeline,indent=2),encoding='utf-8')
        # One overall normalization pass; no gate, time stretching or voice synthesis.
        subprocess.run([FF,'-v','error','-i',str(build/'narration.wav'),'-af','loudnorm=I=-16:TP=-1.5:LRA=11','-ar','48000','-c:a','pcm_s24le','-y',str(R/'SEFI-Narration-Master.wav')],check=True)
        log=open(build/'render.log','w')
        proc=subprocess.Popen([FF,'-v','warning','-f','rawvideo','-pixel_format','rgb24','-video_size','1280x720','-framerate','24','-i','pipe:0','-i',str(R/'SEFI-Narration-Master.wav'),'-c:v','libx264','-preset','medium','-crf','18','-pix_fmt','yuv420p','-c:a','aac','-b:a','160k','-movflags','+faststart','-y',str(R/'SEFI-Graphical-Abstract-Master.mp4')],stdin=subprocess.PIPE,stderr=log)
        for entry in timeline:
            i=entry['scene'];base=Image.open(R/'cards'/f'{i:02d}.png').convert('RGB');count=round(entry['duration']*24)
            for n in range(count):
                t=n/24;im=base.copy();d=ImageDraw.Draw(im)
                # Slowly moving orientation markers; these are internal phase loci.
                if i in [1,2]:
                    for j,rr in enumerate([150,122]):
                        a=t*.65*(1 if j==0 else -1);x=940+rr*math.cos(a);y=350+rr*math.sin(a)
                        d.ellipse((x-8,y-8,x+8,y+8),fill=[TEAL,VIOLET][j],outline=BG,width=2)
                fraction=(entry['start']+t)/cursor;d.rectangle((60,634,60+1160*fraction,638),fill=TEAL)
                # Fade within the recorded margins and added pauses; audio is untouched.
                opacity=min(1,t/.35,(entry['duration']-t)/.35)
                if opacity<1:im=Image.blend(Image.new('RGB',(W,H),BG),im,max(0,opacity))
                proc.stdin.write(im.tobytes())
            print(f"Rendered scene {i}: {entry['duration']:.2f}s",flush=True)
        proc.stdin.close();assert proc.wait()==0;log.close()
        master=R/'SEFI-Graphical-Abstract-Master.mp4';small=R/'SEFI-Graphical-Abstract-Under-10MB.mp4'
        bitrate=int(8_800_000*8/cursor-80000-12000)
        args=[FF,'-v','error','-i',str(master),'-c:v','libx264','-preset','medium','-b:v',str(bitrate),'-pix_fmt','yuv420p','-passlogfile',str(build/'encode')]
        if master.stat().st_size<10_000_000:shutil.copyfile(master,small)
        else:
            subprocess.run(args+['-pass','1','-an','-f','null','-y','NUL'],check=True)
            subprocess.run(args+['-pass','2','-c:a','aac','-b:a','80k','-movflags','+faststart','-y',str(small)],check=True)
        assert small.stat().st_size<10_000_000
        (R/'README.md').write_text('''# SEFI graphical abstract project

The two MP4 files contain the same complete author narration. The Master is the high-quality edition; Under-10MB is the smaller submission copy. highlight.jpg is the matching manuscript image.

All ten source recordings are preserved. Several supplied WAV-named files were Studio One ZIP containers; their embedded lossless FLAC files and original containers are included. No spoken samples were removed, no synthetic voice or music was added, and no voice was time stretched. The overall narration was loudness normalized. Added pauses and a three-second closing hold preserve the ending.

Diagrams distinguish internal phase space, a numerical scalar benchmark, conventional ideal optical readout, ideal helix geometry, and cosmological dilution laws. They are not experimental measurements or a derived particle identification. The radial profile is copied from the manuscript's reproducibility supplement.

Rebuild: install Pillow and NumPy; put FFmpeg on PATH, then run `python build_project.py --render`. Windows Segoe UI fonts are used. timeline.json records scene boundaries. transcript.json is the automatic timing reference, not an authoritative verbatim transcript. Source recordings determine the actual spoken content.

Research: https://github.com/JasonSEFIDEFI/Research
''',encoding='utf-8')
        print(json.dumps(dict(duration=cursor,master_bytes=master.stat().st_size,submission_bytes=small.stat().st_size)),flush=True)
        subprocess.run([__import__('sys').executable,str(R/'add_opening.py')],check=True)
        subprocess.run([__import__('sys').executable,str(R/'clean_transition_audio.py'),'--refresh-source'],check=True)
