# SEFI graphical abstract project

Manuscript title: **SEFI: The Single Entity Field Interpretation — Formal Mathematical Construction**. ABSTRACT.txt preserves the author's exact abstract wording. A three-second opening card shows the registered manuscript title before the complete narration.

The two MP4 files contain the same complete author narration. Master is the high-quality edition; Under-10MB is the upload edition. If the master already fits below 10 MB, these editions are identical and no additional compression is applied. highlight.jpg is the matching manuscript image.

All ten original recordings are retained in full. Several supplied WAV-named files were Studio One ZIP containers; their embedded lossless FLAC files and original containers are included. The other recordings retain their original 24-bit WAV files. Playback copies were resampled, and the combined narration was loudness normalized. Mic-approach sounds in the nonspoken lead-ins of scenes 5, 7 and 9 were muted, with short fades ending before speech. No narration was cut, and video timing is unchanged. No voice synthesis, music, noise gate, or time stretching was used. Added pauses and a three-second closing hold preserve the ending. The supplied quiet recording is archived with the sources; added pauses use digital silence. audio-cleanup.json documents the edit windows; clean_transition_audio.py performs the repair.

Diagrams distinguish internal phase space, a numerical scalar benchmark, conventional ideal optical readout, ideal helix geometry, and cosmological dilution laws. They are not experimental measurements or a derived particle identification. The radial profile is copied from the manuscript's reproducibility supplement.

Rebuild: install Pillow and NumPy; put FFmpeg on PATH, then run `python build_project.py --render`. Windows Segoe UI and Segoe UI Symbol fonts are used. timeline.json records scene boundaries. transcript.json is an automatic timing reference, not an authoritative verbatim transcript. The source recordings determine the actual spoken content.

The manuscript folder contains the current PDF and source archive. verification.json records export checks; SHA256.json records file hashes. Intermediate render files are excluded from the complete ZIP.

Research: https://github.com/JasonSEFIDEFI/Research
