# SEFI manuscript and computational material

**SEFI: The Single Entity Field Interpretation — Formal Mathematical Construction**

The article introduces the Single Entity Field Interpretation following the phase-coherent GWFM construction. Its definitions and arguments are self-contained. Related DEFI, geometric, photonic, DNA, and phase-dynamics works are linked as companion studies. The equations specify one mathematical realization of the interpretation; electron and positron identification remains open.

## Contents

- `main.tex`: editable manuscript; manual bibliography included.
- `main.pdf`: compiled manuscript.
- `figures/`: four deterministic vector illustrations.
- `reproducibility/build_examples.py`: calculations, checks, and figure generation.
- `reproducibility/radial_benchmark.py`: independent regeneration of the local radial profile, grid refinement, domain check, and frequency branch.
- `reproducibility/verification.json`: current computational verification results and scope.
- `VIDEO-ABSTRACT-SCRIPT.md`: scene-by-scene recording script.

## Rebuild

Use Python 3 with NumPy >=2 and ReportLab. From `reproducibility/`, run:

    python -X utf8 radial_benchmark.py
    python -X utf8 build_examples.py

The included profile and results allow the second command to run independently. The first command performs the slower complete radial calculation. No V-drive or original submission files are required. Coordinates, curves and localized profiles are mathematical examples, not experimental observations.

Compile `main.tex` with a REVTeX-capable LaTeX installation. Run `pdflatex -interaction=nonstopmode -halt-on-error main.tex` twice to resolve references. The included figure PDFs are referenced relative to the project. A separate BibTeX run is unnecessary.

The calculation scripts verify specified identities and finite-grid results. They do not establish continuum stability, an electron/positron derivation, or physical unification. Figures are mathematical illustrations, not experimental observations.
