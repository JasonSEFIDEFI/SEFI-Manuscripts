"""Deterministic examples and vector figures for the SEFI manuscript.
All curves are analytic or numerical illustrations; no experimental data.
"""
from pathlib import Path
import json,math
import numpy as np
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor
ROOT=Path(__file__).resolve().parent;FIG=ROOT.parent/'figures';FIG.mkdir(exist_ok=True)
checks=[]
def check(name,condition,**details):
    checks.append(dict(name=name,passed=bool(condition),details=details))
    if not condition:raise AssertionError(name)

# Two-channel coherent readout, tagging, and projection obstruction.
H=np.array([[1,1],[1,-1]],complex)/np.sqrt(2)
phases=np.linspace(0,2*np.pi,601)
error=0.
for th in phases:
    state=H@np.diag([1,np.exp(1j*th)])@H@np.array([1,0])
    error=max(error,abs(abs(state[0])**2-np.cos(th/2)**2))
check('interferometer_exact_readout',error<1e-12,max_error=error)
for gamma in [0.,.4,1.]:
    # Equal-amplitude arms; real tag overlap gamma.
    p=(1+gamma*np.cos(phases))/2
    check(f'tag_visibility_{gamma}',abs((p.max()-p.min())/(p.max()+p.min())-gamma)<1e-12)
P=np.diag([1.,0.]);rho=np.diag([0.,1.]);trace=float(np.trace(P@rho@P))
check('bare_projection_not_trace_preserving',trace==0,trace_after_projection=trace)

# Exact scalar mediator susceptibility and potential lower bound.
a=.3;b=.4;K=np.array([[1,0,0,0],[0,1,a,b],[0,a,1,0],[0,b,0,1.]])
e,V=np.linalg.eigh(K);h=np.array([0.,1.,.2,-.1]);mu=3.
G=float(h@np.linalg.solve(K,h)/mu**2)
closed=(h[0]**2+h[2]**2+h[3]**2+(h[1]-a*h[2]-b*h[3])**2/(1-a*a-b*b))/mu**2
check('identity_spectrum',np.max(abs(e-np.array([.5,1,1,1.5])))<1e-12)
check('identity_susceptibility',abs(G-closed)<1e-12,G=G)
rng=np.random.default_rng(20261029);maxerr=0.
for _ in range(100):
    density=rng.uniform(0,3);I=rng.normal(size=4);m2=1.;eta=1.
    full=m2*density+eta*density**3/3+mu**2*(I@K@I)/2-density*(h@I)
    shifted=I-np.linalg.solve(K,h)*density/mu**2
    reduced=mu**2*(shifted@K@shifted)/2+m2*density-G*density**2/2+eta*density**3/3
    maxerr=max(maxerr,abs(full-reduced))
check('potential_completion_of_square',maxerr<1e-12,max_error=maxerr)
bound_excess=0.
for z in np.linspace(-.4,.4,101):
    R=float(h@np.linalg.solve(K+z*np.eye(4),h)/mu**2);delta=abs(z)/e.min()
    bound_excess=max(bound_excess,abs(R-G)-G*delta/(1-delta))
check('response_error_bound_sample',bound_excess<1e-12,max_excess=bound_excess)

# Helix geometry: exact parameterization and fourth-order derivative check.
R=10.5;pitch=34.;B=pitch/(2*np.pi);gold=(1+np.sqrt(5))/2
kappa=R/(R*R+B*B);tau=B/(R*R+B*B);ratio=kappa/tau
check('helix_ratio',abs(ratio-2*np.pi*R/pitch)<1e-12)
check('rounded_DNA_ratio_is_not_exact_golden',abs(ratio-np.pi/gold)>1e-4,
      ratio=ratio,golden_reference=float(np.pi/gold),relative_difference=float((ratio/(np.pi/gold))-1),
      scope='Illustrative ideal-helix dimensions, not a structural-data fit')
u=np.linspace(0,4*np.pi,10001);du=u[1]-u[0]
curve=np.column_stack([R*np.cos(u),R*np.sin(u),B*u])
d1=np.gradient(curve,du,axis=0,edge_order=2);d2=np.gradient(d1,du,axis=0,edge_order=2);d3=np.gradient(d2,du,axis=0,edge_order=2)
cross=np.cross(d1,d2);kn=np.linalg.norm(cross,axis=1)/np.linalg.norm(d1,axis=1)**3
tn=np.einsum('ni,ni->n',cross,d3)/np.linalg.norm(cross,axis=1)**2
check('helix_numerical_derivative_crosscheck',max(abs(kn[10:-10]/kappa-1).max(),abs(tn[10:-10]/tau-1).max())<2e-6)

# Exact prescribed-FLRW mode: a=t^(2/3), phi=t^-1 exp(-imt).
t=np.geomspace(1,100,501);m=1.;scale=t**(2/3)
f=np.exp(-1j*m*t)/t
fd=f*(-1/t-1j*m);fdd=f*(2/t**2+2j*m/t-m*m)
ode=np.max(abs(fdd+2*fd/t+m*m*f))
Qdensity=1j*(f.conj()*fd-fd.conj()*f)
eps=2*m*m/t**2+1/t**4;pressure=1/t**4
check('FLRW_mode_equation',ode<1e-12,residual=float(ode))
check('FLRW_comoving_charge',np.max(abs(scale**3*Qdensity-2*m))<1e-12)
cont=-4*m*m/t**3-4/t**5+2*(eps+pressure)/t
check('FLRW_stress_continuity',np.max(abs(cont))<1e-12)
friedmann_ratio=(eps*t*t)/(eps[0]*t[0]**2)
check('prescribed_dust_metric_not_exact_scalar_backreaction',np.ptp(friedmann_ratio)>.2,
      explanation='No constant gravitational normalization makes H^2 proportional to this exact scalar energy for all times.')

# Existing finite-domain radial benchmark: verify source data and conditions.
rad=json.loads((ROOT/'radial-results.json').read_text(encoding='utf-8'))
run=[q for q in rad['runs'] if q['h']==.025 and q['R']==30][0]
check('radial_residual_and_virial',run['residual']<2e-9 and run['relative_virial']<1e-5,
      residual=run['residual'],relative_virial=run['relative_virial'],scope='Finite-domain local scalar benchmark, no full nonlinear stability claim')
stored=np.load(ROOT/'radial-profile.npz');rr=stored['r'];ff=stored['f'];spacing=rr[1]-rr[0]
lap=(ff[2:]-2*ff[1:-1]+ff[:-2])/spacing**2+(ff[2:]-ff[:-2])/(spacing*rr[1:-1])
force=lambda z:(1-.8**2)*z-2*z**3+z**5
direct_res=max(float(np.max(abs(lap-force(ff[1:-1])))),abs(6*(ff[1]-ff[0])/spacing**2-force(ff[0])))
direct_Q=2*.8*4*np.pi*np.trapezoid(rr**2*ff**2,rr)
check('stored_radial_profile_independent_substitution',direct_res<1e-8 and abs(direct_Q-run['orientation_charge'])<1e-9,
      direct_equation_residual=direct_res,direct_charge_error=abs(direct_Q-run['orientation_charge']))

# Plain vector plotting, with labels and equal axes where appropriate.
navy=HexColor('#142b46');purple=HexColor('#6356ba');teal=HexColor('#008d91');gray=HexColor('#5c6a78')
def begin(name,title):
    c=canvas.Canvas(str(FIG/name),pagesize=(600,300));c.setTitle(title);c.setFont('Helvetica-Bold',14);c.setFillColor(navy);c.drawString(28,277,title);return c
def panel(c,box,xrange,yrange,title,xlabel,ylabel):
    x0,y0,w,hh=box
    def xy(x,y):return x0+w*(x-xrange[0])/(xrange[1]-xrange[0]),y0+hh*(y-yrange[0])/(yrange[1]-yrange[0])
    c.setFont('Helvetica-Bold',10);c.setFillColor(navy);c.drawString(x0,y0+hh+13,title)
    c.setStrokeColor(HexColor('#dbe1e8'));c.setLineWidth(.5)
    for xx in np.linspace(*xrange,5):
        px,_=xy(xx,0);c.line(px,y0,px,y0+hh);c.setFont('Helvetica',7);c.setFillColor(gray);c.drawCentredString(px,y0-12,f'{xx:.2g}')
    for yy in np.linspace(*yrange,5):
        _,py=xy(0,yy);c.line(x0,py,x0+w,py);c.drawRightString(x0-5,py-2,f'{yy:.2g}')
    c.setFont('Helvetica',9);c.drawCentredString(x0+w/2,y0-28,xlabel);c.saveState();c.translate(x0-32,y0+hh/2);c.rotate(90);c.drawCentredString(0,0,ylabel);c.restoreState()
    return xy
def line(c,xy,x,y,color):
    c.setStrokeColor(color);c.setLineWidth(1.7);p=c.beginPath();p.moveTo(*xy(float(x[0]),float(y[0])))
    for xx,yy in zip(x[1:],y[1:]):p.lineTo(*xy(float(xx),float(yy)))
    c.drawPath(p)
def footer(c,text):c.setFont('Helvetica',8);c.setFillColor(gray);c.drawString(28,15,text);c.save()
c=begin('phase-and-readout.pdf','Conjugate phase and coherent readout')
xy=panel(c,(65,65,175,175),(-1.1,1.1),(-1.1,1.1),'(a) Opposite phase directions','real amplitude','imaginary amplitude')
z=np.linspace(0,2*np.pi,301);line(c,xy,np.cos(z),np.sin(z),purple)
for sign,col in [(1,purple),(-1,teal)]:
    angle=sign*.8;point=xy(np.cos(angle),np.sin(angle));c.setFillColor(col);c.circle(*point,3,fill=1,stroke=0)
xy=panel(c,(350,65,210,175),(0,2*np.pi),(0,1),'(b) Two-path output probability','relative path phase (rad)','output probability')
for gamma,col in [(1,purple),(.4,teal),(0,gray)]:line(c,xy,phases,(1+gamma*np.cos(phases))/2,col)
footer(c,'Analytic illustrations. Visibility = 1, 0.4, 0; quantum readout requires the stated Born assumption.')
c=begin('localization-and-spectrum.pdf','Local scalar benchmark and internal stiffness')
data=np.load(ROOT/'radial-profile.npz');r=data['r'];f=data['f'];sel=r<=12
xy=panel(c,(55,65,205,175),(0,12),(0,1.4),'(a) Radial profile, frequency 0.8','dimensionless radius','field amplitude')
line(c,xy,r[sel],f[sel],purple)
xx=np.linspace(0,.99,301)
xy=panel(c,(355,65,205,175),(0,1),(0,2),'(b) Identity stiffness eigenvalues','mixing magnitude r','stiffness eigenvalue')
for y,col in [(1-xx,purple),(np.ones_like(xx),gray),(1+xx,teal)]:line(c,xy,xx,y,col)
footer(c,'The radial profile is a finite-domain Q-ball benchmark. Stiffness eigenvalues are not particle masses.')
c=begin('dna-geometric-map.pdf','Ideal helix geometry: an explicit spatial mapping')
uu=np.linspace(0,4*np.pi,501)
xy=panel(c,(55,65,205,175),(-14,14),(0,68),'(a) Two idealized strands','transverse coordinate (angstrom)','axial coordinate (angstrom)')
for phase,col in [(0,purple),(np.pi,teal)]:line(c,xy,R*np.cos(uu+phase),B*uu,col)
pp=np.linspace(28,42,301)
xy=panel(c,(355,65,205,175),(28,42),(1.5,2.4),'(b) Curvature / torsion','pitch (angstrom)','dimensionless ratio')
line(c,xy,pp,2*np.pi*R/pp,purple);line(c,xy,pp,np.ones_like(pp)*np.pi/gold,gray)
footer(c,'Ideal geometric curves, not molecular measurements. The reference pi/golden-ratio is not a fitted law.')
c=begin('cosmological-map.pdf','Expansion mapping: conserved charge and energy dilution')
aa=np.geomspace(1,10,301);logx=np.log10(aa)
xy=panel(c,(65,65,490,175),(0,1),(-4,0),'Prescribed FLRW benchmarks','log10(scale factor)','log10(normalized density)')
for vals,col in [(aa**-3,purple),(aa**-4,teal),((2*aa**-3+aa**-6)/3,gray)]:line(c,xy,logx,np.log10(vals),col)
footer(c,'Purple: charge / massive limit; teal: radiation; gray: exact scalar-mode energy on prescribed a=t^(2/3).')
summary=dict(check_count=len(checks),all_passed=all(q['passed'] for q in checks),checks=checks,
             radial=run,DNA=dict(radius_angstrom=R,pitch_angstrom=pitch,kappa=kappa,torsion=tau,ratio=ratio),
             figures='All figures are deterministic mathematical illustrations, not experimental observations.')
(ROOT/'verification.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(f'{len(checks)} checks passed; four vector figures written.')
