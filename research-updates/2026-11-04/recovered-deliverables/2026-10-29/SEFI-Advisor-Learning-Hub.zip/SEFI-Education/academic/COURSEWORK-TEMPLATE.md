# Course or study entry

- Actual course/topic title:
- Institution or source:
- Type: coursework / independent study / research lesson
- Status: planned / in progress / completed
- Learning objective:
- Work completed and evidence:
- What is still unclear:
- Connection to a research or software question:
- Next step agreed with an advisor:

Do not treat this template as an official transcript. Keep grades, identifiers and restricted assignments out of public commits.
