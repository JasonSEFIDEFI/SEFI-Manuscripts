# Coursework and independent-learning roadmap

Current enrollment: Bachelor of Science in Information Technology, American InterContinental University, in progress. Specific course completions and grades are not recorded in this public template.

Use official university records for course titles, degree requirements, transfer credit and enrollment status. The areas below are independent-learning planning topics, not approved degree requirements or claims of completed study.

| Area | Practice task | Evidence to discuss with an advisor |
| --- | --- | --- |
| Programming | Implement a small calculation with explicit inputs, units and error handling. | Code, worked examples, meaningful tests and a reproduction command. |
| Linear algebra | Explore complex amplitudes, matrices, eigenvalues and normalization. | Hand calculation compared with a numerical example. |
| Calculus and differential equations | Relate an equation to initial/boundary conditions and a computed solution. | Derivation, residual, convergence checks and stated limitations. |
| Numerical methods | Compare grid sizes, domains and solver stopping criteria. | Error tables, reference solutions, failures and sensitivity results. |
| Physics and measurement | Distinguish a state, its evolution and an observable/readout rule. | A specified model and comparison with an established reference. |
| Scientific communication | Explain one result to a general reader without overstating its scope. | A diagram, concise explanation, references and open questions. |

## A meeting outcome worth recording

Agree on one manageable task, one reviewable output, one source of feedback and a date chosen by the participant. The portal's study and review sections can hold this record locally.
