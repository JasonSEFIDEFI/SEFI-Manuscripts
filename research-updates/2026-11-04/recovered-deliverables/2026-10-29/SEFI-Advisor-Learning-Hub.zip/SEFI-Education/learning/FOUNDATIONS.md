# Four starting activities

## 1. Relative phase and readout

For the specified balanced two-path model, p0 = (1 + V cos(alpha))/2 and p1 = 1 - p0. Set V=1 and compare alpha=0, pi/2 and pi. Then set V=0. The demonstration assumes a coherent amplitude description and Born readout; it does not derive quantum probabilities from the scalar field model.

## 2. A spatial helix

Write X(u)=(R cos u, R sin u, bu), with b=P/(2 pi). Derive curvature R/(R^2+b^2), torsion b/(R^2+b^2) and their ratio 2 pi R/P. Change pitch at fixed radius. Explain why this geometric identity is not a biological selection law and why u is not automatically time.

## 3. What a check checks

Choose a computed solution. Distinguish discrete equation residual, conserved-quantity drift, grid dependence, domain dependence and perturbation response. Describe one conclusion each could support and one conclusion it could not support alone.

## 4. A falsifiable comparison

Choose one model claim and write its assumptions, consequence, measurable quantity, established baseline and uncertainty. Explain what outcome would challenge it. Include negative results and boundary cases rather than selecting only successful runs.

Read the bundled manuscripts for their full definitions and references. GWFM and SEFI are the author's research proposals; the exercises do not establish their broader physical interpretation.
