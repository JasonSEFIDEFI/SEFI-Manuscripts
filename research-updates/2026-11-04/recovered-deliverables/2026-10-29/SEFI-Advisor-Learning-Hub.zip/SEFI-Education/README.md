# SEFI Education - Advisor & Learning Hub

A portable browser interface for **Jason Duran Dutton's research teaching materials and personal academic-development record**.

## Public portal

The public portal is https://sefi-research-learning.jasondurandutton.chatgpt.site . The ZIP is also available from its Download ZIP link. Public access is configured separately from GitHub repository visibility.

## Open the portable copy

1. Download and fully extract `SEFI-Advisor-Learning-Hub.zip`.
2. Open `index.html` in a modern desktop browser such as Edge, Chrome, Firefox or Safari.
3. Use the sidebar to navigate. No account, installation, build process or network connection is required for the bundled interface, papers, images and videos. Online source links require Internet access. Some mobile file managers restrict local HTML; a desktop browser is recommended.

If local-file access is restricted by your browser, serve the extracted folder with any static web server. With Python installed: `python -m http.server 8877 --bind 127.0.0.1`, then visit `http://127.0.0.1:8877`.

## What is included

- **Advisor overview:** guided reading order, scope of the research and a focused meeting agenda.
- **Research library:** the latest prepared GWFM and SEFI manuscripts, source archives, corrected abstract videos, highlights, and an evidence/limits table.
- **Learning studio:** four learning activities, self-checks, an interactive interference reference and an ideal-helix calculator.
- **Study record:** an initially empty record for real coursework and independent study. The current program is AIU's BSIT, in progress. No grades, completed courses or institutional credit are invented.
- **Review notebook:** locally editable questions, feedback and next steps; meeting-note export.
- **Portable workspace:** export/import progress, study entries and notes as JSON. Imports are validated, not executed. Importing replaces the local record only after a confirmation.

## Notes and privacy

The portal sends no notes to an advisor, university, GitHub or server. Browser storage is used when available. File-browser storage behavior differs, so export before closing or moving the folder. Exported notes may contain personal information; share them deliberately. The shipped ZIP contains no personal review notes, student identifier, grades, transcript, credentials or private chat history. The interface is not an encrypted records system.

The mail link opens your configured mail app and does not send a message. Printing invokes the browser's print dialog. There is no hosted service, analytics, remote font or external script dependency.

## Research scope

The reading sequence is **GWFM -> SEFI -> specialized work**. Publicly available author manuscripts and local numerical checks do not establish journal acceptance, experimental particle identification, general stability, or a unified physical law. The educational examples distinguish established mathematical references from proposed interpretations. Interference uses a specified coherent-amplitude/Born model; the helix calculator supplies geometry, not molecular measurements.

## Edit and verify

- `content.js`: public manuscript descriptions, evidence table and learning activities.
- `index.html`, `style.css`, `app.js`: complete buildless interface.
- `learning/`: educational notes and exercises.
- `academic/`: templates and a learning roadmap, not official university records.
- `assets/`: bundled manuscripts, source ZIPs and media.
- `ASSET-PROVENANCE.json`: binary checksums and sizes.
- `QA.md`: checks performed and practical limitations.

Run mathematical and workspace-validation tests with **Node.js 18 or newer**: `node --test tests/*.test.cjs`. Node is needed only for developer tests, not to use the portal.

## Ownership and contribution

Copyright Jason Duran Dutton. This package is shared for education, research discussion and advisor review. No broad software or manuscript license is granted implicitly. Existing manuscript and repository notices remain applicable. Do not upload university assignments, instructor materials, grades or personal records without the relevant rights and permission.

Corrections should identify the file, mathematical assumption, reproduction steps and expected result. A proposed physical interpretation and a reproducible software result should be evaluated separately.

[Research portfolio](https://github.com/JasonSEFIDEFI/Research) | [Scientific software](https://github.com/JasonSEFIDEFI/SEFI-PY)
