"""Explain one correction and compare noisy calibration on a synthetic drift field."""

import json
import math
import random
from statistics import mean

from quantum.saddle_displacement import gaussian_entanglement_fidelity
from quantum.saddle_transfer import (
    CALIBRATION_DIRECTIONS, CALIBRATION_PAIRS, SIGMA, TEST_DIRECTIONS, TEST_PAIRS,
    bilinear_features, height_difference, saddle_height,
)

BUDGETS = (4, 8, 16, 32)
REPEATS = 64
SEED = 20261122
READOUT_SD = 0.15
TARGET = 0.95


def drift_height(x, y):
    """Synthetic periodic disturbance with curved and cross-coupled components."""
    return math.cos(0.8 * x - 0.4 * y) + 0.6 * math.sin(0.3 * x + y)


def _shot(pair, direction):
    return (
        height_difference(pair, direction, saddle_height),
        bilinear_features(pair, direction),
        height_difference(pair, direction, drift_height),
    )


def _fit(readings, shots):
    features = [shot[0] for shot in shots]
    saddle_gain = sum(x * y for x, y in zip(features, readings, strict=True))
    saddle_gain /= sum(x*x for x in features)
    # The four axis shots isolate the four bilinear coefficients in turn.
    independent = tuple(mean(readings[index::4]) for index in range(4))
    return saddle_gain, independent


def _score(predict, shots):
    return mean(gaussian_entanglement_fidelity(SIGMA, actual - predict(saddle, linear))
                for saddle, linear, actual in shots)


def run():
    rng = random.Random(SEED)
    layout = tuple(_shot(pair, direction) for pair in CALIBRATION_PAIRS
                   for direction in CALIBRATION_DIRECTIONS)
    evaluation = tuple(_shot(pair, direction) for pair in TEST_PAIRS
                       for direction in TEST_DIRECTIONS)
    calibration = layout * (max(BUDGETS) // len(layout))
    scores = {budget: [] for budget in BUDGETS}
    for repeat in range(REPEATS):
        readings = [actual + rng.gauss(0, READOUT_SD) for _, _, actual in calibration]
        for budget in BUDGETS:
            gain, slopes = _fit(readings[:budget], calibration[:budget])
            scores[budget].append((
                _score(lambda saddle, linear: gain * saddle, evaluation),
                _score(lambda saddle, linear: sum(a*b for a, b in zip(slopes, linear)),
                       evaluation),
            ))
        if repeat == 0:
            trace = explain(_fit(readings[:BUDGETS[0]], layout)[0])

    rows = [{"shots": budget, "saddle": mean(row[0] for row in scores[budget]),
             "independent_bilinear": mean(row[1] for row in scores[budget])}
            for budget in BUDGETS]
    return {
        "example": trace,
        "held_out_cases": len(evaluation),
        "calibration_repeats": REPEATS,
        "mean_bell_fidelity_without_correction": _score(lambda saddle, linear: 0, evaluation),
        "mean_bell_fidelity_by_shots": rows,
        "fidelity_target": TARGET,
        "first_tested_budget_to_reach_target": {
            method: next((row["shots"] for row in rows if row[method] >= TARGET), None)
            for method in ("saddle", "independent_bilinear")
        },
    }


def explain(gain):
    pair = TEST_PAIRS[0]
    direction = TEST_DIRECTIONS[-1]
    predicted = gain * height_difference(pair, direction, saddle_height)
    actual = height_difference(pair, direction, drift_height)
    residual = actual - predicted
    return {
        "logical_locations": pair,
        "sideways_shift": tuple(map(float, direction)),
        "saddle_height_change_at_each_location": [
            float(saddle_height(x + direction[0], y + direction[1]) - saddle_height(x, y))
            for x, y in pair
        ],
        "fitted_gain": gain,
        "predicted_differential_vertical_shift": float(predicted),
        "actual_shift_difference_for_scoring_only": actual,
        "residual_after_correction": float(residual),
        "bell_fidelity": gaussian_entanglement_fidelity(SIGMA, residual),
    }


if __name__ == "__main__":
    print(json.dumps(run(), indent=2))
