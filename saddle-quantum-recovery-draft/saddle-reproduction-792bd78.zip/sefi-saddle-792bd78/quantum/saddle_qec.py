"""Exact finite saddle model of three-qubit bit-flip repetition QEC.

A matrix is a mapping from (row, column) to its entry; omitted entries are zero.
Each channel term is (weight, basis map), representing a Kraus operator with
amplitude sqrt(weight) on the indicated basis transitions.
"""

import json
from fractions import Fraction

CODEWORDS = (0b000, 0b111)
FLIP_MASKS = (0b000, 0b001, 0b010, 0b100)
ENCODER = dict(enumerate(CODEWORDS))


def apply_channel(matrix, operators):
    """Apply the weighted Kraus sum to a sparse matrix, including coherences."""
    result = {}
    for weight, mapping in operators:
        for (row, column), value in matrix.items():
            if row in mapping and column in mapping:
                key = mapping[row], mapping[column]
                result[key] = result.get(key, 0) + weight * value
    return {key: value for key, value in result.items() if value != 0}


def encode(logical_matrix):
    """Map a qubit to the span of |000> and |111>."""
    return apply_channel(logical_matrix, ((1, ENCODER),))


def flip_channel(probabilities, *, qubits=3):
    """Random X masks on a 1- or 3-qubit register, with exact rational weights."""
    if qubits not in (1, 3):
        raise ValueError("only one or three qubits are supported")
    dimension = 1 << qubits
    weights = {mask: Fraction(p) for mask, p in probabilities.items()}
    if (any(not isinstance(mask, int) or not 0 <= mask < dimension for mask in weights)
            or any(p < 0 for p in weights.values()) or sum(weights.values()) != 1):
        raise ValueError("expected valid flip masks and nonnegative weights summing to one")
    return tuple((p, {basis: basis ^ mask for basis in range(dimension)})
                 for mask, p in weights.items() if p)


def _height(x, y, flat):
    return 0 if flat else x*x - y*y


def saddle_coordinates(basis, *, flat=False):
    """Label the eight physical basis states by two saddle points and four heights."""
    if not isinstance(basis, int) or not 0 <= basis < 8:
        raise ValueError("expected a three-qubit basis index")
    logical = int(basis.bit_count() >= 2)
    mask = basis ^ CODEWORDS[logical]
    x, y = logical, 1 - logical
    return x, y, _height(x, y, flat) + FLIP_MASKS.index(mask)


def recovery(decoder="saddle", *, flat=False):
    """Return logical recovery Kraus terms, requiring only the received state."""
    if decoder == "standard":
        return tuple((1, {word ^ mask: bit for bit, word in enumerate(CODEWORDS)})
                     for mask in FLIP_MASKS)

    sectors = [{} for _ in FLIP_MASKS]
    for basis in range(8):
        x, y, z = saddle_coordinates(basis, flat=flat)
        residual = z - _height(x, y, flat)
        sectors[residual][basis] = x

    if decoder == "saddle":
        return tuple((1, sector) for sector in sectors)
    if decoder == "projection":
        # Keep the zero-offset projection and reset leaked states to logical |0>.
        return ((1, sectors[0]),) + tuple(
            (1, {basis: 0}) for sector in sectors[1:] for basis in sector
        )
    if decoder == "measured":
        # A full coordinate measurement reveals the logical bit and kills coherence.
        return tuple((1, {basis: bit}) for sector in sectors for basis, bit in sector.items())
    raise ValueError(f"unknown decoder: {decoder}")


def logical_channel(matrix, probabilities, decoder="saddle", *, flat=False):
    """Compose encoding, stipulated random bit flips, and unconditional recovery."""
    noisy = apply_channel(encode(matrix), flip_channel(probabilities))
    return apply_channel(noisy, recovery(decoder, flat=flat))


def _bell_fidelity(channel):
    """Bell overlap from (id ⊗ channel)(|Φ+><Φ+|), with exact real weights."""
    overlap = 0
    for row in range(2):
        for column in range(2):
            unit = {(row, column): 1}
            overlap += channel(unit).get((row, column), 0)
    return Fraction(overlap, 4)


def report():
    """Exact entanglement fidelities for fixed controls and out-of-model errors."""
    probabilities = {0: Fraction(1, 2), 1: Fraction(1, 8),
                     2: Fraction(1, 8), 4: Fraction(1, 4)}
    values = {
        decoder: _bell_fidelity(lambda matrix: logical_channel(matrix, probabilities, decoder))
        for decoder in ("saddle", "standard", "projection", "measured")
    }
    values["flat"] = _bell_fidelity(
        lambda matrix: logical_channel(matrix, probabilities, flat=True)
    )
    uncoded_noise = flip_channel({0: Fraction(7, 8), 1: Fraction(1, 8)}, qubits=1)
    values["uncoded"] = _bell_fidelity(lambda matrix: apply_channel(matrix, uncoded_noise))
    values["double_flip"] = _bell_fidelity(lambda matrix: logical_channel(matrix, {3: 1}))
    # A physical Z on the low-order bit induces this sign on encoded matrix units.
    values["phase_flip"] = _bell_fidelity(lambda matrix: apply_channel(
        {(row, column): value * (-1)**((row ^ column) & 1)
         for (row, column), value in encode(matrix).items()},
        recovery(),
    ))
    return values


if __name__ == "__main__":
    print(json.dumps({name: str(value) for name, value in report().items()},
                     indent=2, sort_keys=True))
