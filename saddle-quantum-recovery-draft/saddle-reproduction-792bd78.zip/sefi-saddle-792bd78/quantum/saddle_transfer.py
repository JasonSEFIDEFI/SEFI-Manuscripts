"""Test how well a calibration transfers to unseen pairs of logical locations."""

from fractions import Fraction
import json
from statistics import mean

from quantum.saddle_displacement import gaussian_entanglement_fidelity

CALIBRATION_PAIRS = (((0, 0), (1, 0)), ((0, 0), (0, 1)))
CALIBRATION_DIRECTIONS = ((1, 0), (0, 1))
TEST_PAIRS = (((1, -1), (2, 0)), ((-1, 0), (1, -1)),
              ((1, 1), (0, -1)), ((-2, 1), (-1, 0)))
TEST_DIRECTIONS = tuple((Fraction(dx, 2), Fraction(dy, 2))
                        for dx in (-2, -1, 1, 2) for dy in (-2, -1, 1, 2))
SIGMA = 0.5


def saddle_height(x, y):
    return x*x - y*y


def height_difference(pair, displacement, surface):
    dx, dy = displacement
    first, second = pair
    x0, y0 = first
    x1, y1 = second
    return (surface(x1 + dx, y1 + dy) - surface(x1, y1)
            - surface(x0 + dx, y0 + dy) + surface(x0, y0))


def bilinear_features(pair, displacement):
    (x0, y0), (x1, y1) = pair
    dx, dy = displacement
    return ((x1 - x0) * dx, (x1 - x0) * dy,
            (y1 - y0) * dx, (y1 - y0) * dy)


def compare(noise):
    """Fit on the specified calibration shots and evaluate held-out pairs."""
    shots = tuple((pair, direction) for pair in CALIBRATION_PAIRS
                  for direction in CALIBRATION_DIRECTIONS)
    first_shot = shots[0]
    first_reading = noise(*first_shot)
    gain = Fraction(first_reading) / height_difference(*first_shot, saddle_height)
    independent_slopes = (first_reading,) + tuple(noise(*shot) for shot in shots[1:])

    def score(predict, shot_count):
        residuals = [noise(pair, direction) - predict(pair, direction)
                     for pair in TEST_PAIRS for direction in TEST_DIRECTIONS]
        return {
            "calibration_shots": shot_count,
            "mean_bell_fidelity": mean(gaussian_entanglement_fidelity(SIGMA, residual)
                                       for residual in residuals),
            "mean_squared_residual": str(mean(residual**2 for residual in residuals)),
        }

    def shared_shape(pair, direction):
        xx, _, _, yy = bilinear_features(pair, direction)
        return first_reading * (xx - yy)

    def horizontal_only(pair, direction):
        return first_reading * bilinear_features(pair, direction)[0]

    def independent(pair, direction):
        return sum(slope * feature for slope, feature in
                   zip(independent_slopes, bilinear_features(pair, direction), strict=True))

    return {
        "saddle_one_shot": score(lambda pair, d: gain * height_difference(pair, d, saddle_height), 1),
        "conventional_same_shape_one_shot": score(shared_shape, 1),
        "conventional_independent_one_shot": score(horizontal_only, 1),
        "conventional_independent_four_shots": score(independent, len(shots)),
    }


def report():
    def aligned_field(x, y):
        return x*x - y*y

    def cross_coupled_field(x, y):
        return x*x - y*y + x*y

    return {
        "held_out_pairs": len(TEST_PAIRS),
        "held_out_disturbances_per_pair": len(TEST_DIRECTIONS),
        "gaussian_packet_width": SIGMA,
        "aligned": compare(lambda pair, d: height_difference(pair, d, aligned_field)),
        "cross_coupled": compare(lambda pair, d: height_difference(pair, d, cross_coupled_field)),
    }


if __name__ == "__main__":
    print(json.dumps(report(), indent=2))
