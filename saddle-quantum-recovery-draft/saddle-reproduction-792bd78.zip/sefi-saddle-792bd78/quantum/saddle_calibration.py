"""Compare calibration budgets on a synthetic differential displacement channel."""

from fractions import Fraction
import json
from statistics import mean

from quantum.saddle_displacement import LOCATIONS, gaussian_entanglement_fidelity

SIGMA = 0.5
CALIBRATION = ((1, 0), (0, 1))
HELD_OUT = tuple((Fraction(x, 2), Fraction(y, 2))
                 for x in (-3, -2, -1, 1, 2, 3) for y in (-3, -2, -1, 1, 2, 3))


def saddle_feature(dx, dy):
    """Difference in the two saddle heights' changes under lateral translation."""
    changes = [(x + dx)**2 - (y + dy)**2 - (x*x - y*y) for x, y in LOCATIONS]
    return changes[1] - changes[0]


def _score(noise, correction):
    residuals = [noise(dx, dy) - correction(dx, dy) for dx, dy in HELD_OUT]
    return {
        "mean_bell_fidelity": mean(gaussian_entanglement_fidelity(SIGMA, r)
                                   for r in residuals),
        "mean_squared_residual": float(mean(r*r for r in residuals)),
    }


def compare(transverse_gain):
    """Calibrate on unit axis shifts and score on unseen diagonal disturbances."""
    # Fixed before fitting. The transverse term violates the one-parameter model.
    def noise(dx, dy):
        return dx + dy + transverse_gain * (dx - dy)

    first_direction, second_direction = CALIBRATION
    first_reading = noise(*first_direction)
    saddle_gain = Fraction(first_reading) / saddle_feature(*first_direction)
    second_reading = noise(*second_direction)
    return {
        "no_calibration": {"measurements": 0, **_score(noise, lambda dx, dy: 0)},
        "saddle": {"measurements": 1, **_score(
            noise, lambda dx, dy: saddle_gain * saddle_feature(dx, dy))},
        "linear_shared_slope": {"measurements": 1, **_score(
            noise, lambda dx, dy: first_reading * (dx + dy))},
        "linear_independent_slopes_one_axis": {"measurements": 1, **_score(
            noise, lambda dx, dy: first_reading * dx)},
        "linear_independent_slopes_two_axes": {"measurements": 2, **_score(
            noise, lambda dx, dy: first_reading * dx + second_reading * dy)},
    }


if __name__ == "__main__":
    print(json.dumps({
        "held_out_displacements": len(HELD_OUT),
        "gaussian_packet_width": SIGMA,
        "aligned": compare(0),
        "off_model": compare(Fraction(3, 4)),
    }, indent=2))
