"""Coherent saddle encoding against vertical translations of a height register."""

import argparse
from fractions import Fraction
import json
import math

from quantum.saddle_qec import apply_channel

HEIGHT_BINS = 7
LOCATIONS = ((0, 1), (1, 0))
BELL = {(0, 0): Fraction(1, 2), (0, 3): Fraction(1, 2),
        (3, 0): Fraction(1, 2), (3, 3): Fraction(1, 2)}


def surface_height(logical):
    x, y = LOCATIONS[logical]
    return x*x - y*y


def _index(logical, height):
    return logical * HEIGHT_BINS + height % HEIGHT_BINS


def _with_reference(operators):
    return tuple((weight, {2 * source + ref: 2 * target + ref
                           for source, target in mapping.items() for ref in range(2)})
                 for weight, mapping in operators)


def encode(matrix, *, reference=False, flat=False):
    """Attach a height register at the selected surface's height, coherently."""
    operators = ((1, {bit: _index(bit, 0 if flat else surface_height(bit))
                      for bit in range(2)}),)
    return apply_channel(matrix, _with_reference(operators) if reference else operators)


def translate(matrix, shift, *, differential=0, reference=False):
    """Translate both locations by shift, plus differential at logical location 1."""
    if not isinstance(shift, int) or not isinstance(differential, int):
        raise ValueError("cyclic height shifts must be integers")
    operators = ((1, {_index(bit, z): _index(bit, z + shift + bit * differential)
                      for bit in range(2) for z in range(HEIGHT_BINS)}),)
    return apply_channel(matrix, _with_reference(operators) if reference else operators)


def decode(matrix, *, reference=False, flat=False):
    """Subtract the surface height coherently, then trace out the residual."""
    operators = tuple(
        (1, {_index(bit, residual + (0 if flat else surface_height(bit))): bit
             for bit in range(2)})
        for residual in range(HEIGHT_BINS)
    )
    return apply_channel(matrix, _with_reference(operators) if reference else operators)


def gaussian_entanglement_fidelity(sigma, residual_difference):
    """Continuous Bell fidelity for Gaussian height packets of position SD sigma.

    residual_difference is the separation of the two packet centers after
    decoding. A common translation cancels from this separation.
    """
    if not math.isfinite(sigma) or sigma <= 0 or not math.isfinite(residual_difference):
        raise ValueError("expected positive finite width and finite separation")
    ratio = residual_difference / sigma
    return (1 + math.exp(-ratio * ratio / 8)) / 2


def report():
    encoded_bell = encode(BELL, reference=True)
    noisy = {}
    for shift, weight in ((-2, Fraction(1, 4)), (0, Fraction(1, 2)), (3, Fraction(1, 4))):
        for key, value in translate(encoded_bell, shift, reference=True).items():
            noisy[key] = noisy.get(key, 0) + weight * value

    saddle = decode(noisy, reference=True)
    flat = decode(noisy, reference=True, flat=True)
    height_gap = surface_height(1) - surface_height(0)
    return {
        "cyclic_bell_fidelity": {
            "saddle_decoder": str(sum(saddle.get(key, 0) * value for key, value in BELL.items())),
            "flat_decoder": str(sum(flat.get(key, 0) * value for key, value in BELL.items())),
        },
        "continuous_gaussian_bell_fidelity_sigma_0_5": {
            "saddle_decoder": gaussian_entanglement_fidelity(0.5, 0),
            "flat_decoder": gaussian_entanglement_fidelity(0.5, height_gap),
        },
    }


def differential_report(bin_gap, gaussian_gap, sigma):
    """Evaluate a location-dependent translation using the fixed saddle decoder."""
    encoded = encode(BELL, reference=True)
    noisy = translate(encoded, 0, differential=bin_gap, reference=True)
    decoded = decode(noisy, reference=True)
    return {
        "cyclic_bin_gap": bin_gap,
        "cyclic_bell_fidelity": str(sum(decoded.get(key, 0) * value for key, value in BELL.items())),
        "gaussian_gap": gaussian_gap,
        "gaussian_sigma": sigma,
        "gaussian_bell_fidelity": gaussian_entanglement_fidelity(sigma, gaussian_gap),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--differential", action="store_true",
                        help="run the location-dependent translation control")
    parser.add_argument("--bin-gap", type=int, help="cyclic shift difference (default: 1)")
    parser.add_argument("--gaussian-gap", type=float,
                        help="continuous shift difference (default: 0.2)")
    parser.add_argument("--sigma", type=float, help="Gaussian packet width (default: 0.5)")
    args = parser.parse_args()
    if args.differential:
        try:
            results = differential_report(
                1 if args.bin_gap is None else args.bin_gap,
                0.2 if args.gaussian_gap is None else args.gaussian_gap,
                0.5 if args.sigma is None else args.sigma,
            )
        except ValueError as error:
            parser.error(str(error))
    else:
        if any(value is not None for value in (args.bin_gap, args.gaussian_gap, args.sigma)):
            parser.error("gap and width options require --differential")
        results = report()
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
