"""Channel, phase and entanglement checks for coherent vertical recovery."""

import math
import unittest

from quantum.saddle_displacement import (
    BELL, HEIGHT_BINS, decode, differential_report, encode,
    gaussian_entanglement_fidelity, report, translate,
)


class SaddleDisplacementTest(unittest.TestCase):
    def test_all_matrix_units_under_every_shift(self):
        for shift in range(HEIGHT_BINS):
            for row in range(2):
                for column in range(2):
                    with self.subTest(shift=shift, row=row, column=column):
                        unit = {(row, column): 1}
                        self.assertEqual(decode(translate(encode(unit), shift)), unit)

    def test_bell_state_and_flat_ablation(self):
        for shift in range(HEIGHT_BINS):
            with self.subTest(shift=shift):
                noisy = translate(encode(BELL, reference=True), shift, reference=True)
                self.assertEqual(decode(noisy, reference=True), BELL)
                self.assertEqual(decode(noisy, reference=True, flat=True),
                                 {key: BELL[key] for key in ((0, 0), (3, 3))})
                flat = encode(BELL, reference=True, flat=True)
                self.assertEqual(decode(translate(flat, shift, reference=True),
                                        reference=True, flat=True), BELL)
        self.assertEqual(report()["cyclic_bell_fidelity"],
                         {"saddle_decoder": "1", "flat_decoder": "1/2"})

    def test_gaussian_overlap_against_numerical_integral(self):
        sigma = 0.5
        spacing = 0.002
        for difference in (0, 0.2, 2):
            def packet(height):
                return (2 * math.pi * sigma**2)**(-0.25) * math.exp(
                    -height**2 / (4 * sigma**2)
                )

            overlap = spacing * sum(
                packet(index * spacing) * packet(index * spacing - difference)
                for index in range(-4000, 4001)
            )
            self.assertAlmostEqual(gaussian_entanglement_fidelity(sigma, difference),
                                   (1 + overlap) / 2, places=12)

    def test_differential_translation_preserves_populations_and_erases_phase(self):
        phase_state = {(0, 0): 0.5, (1, 1): 0.5, (0, 1): -0.5j, (1, 0): 0.5j}
        encoded = encode(phase_state)
        for difference in range(1, HEIGHT_BINS):
            for shift in range(HEIGHT_BINS):
                with self.subTest(difference=difference, shift=shift):
                    noisy = translate(encoded, shift, differential=difference)
                    self.assertEqual(decode(noisy), {(0, 0): 0.5, (1, 1): 0.5})
        wrapped = translate(encoded, -2, differential=HEIGHT_BINS)
        self.assertEqual(decode(wrapped), phase_state)
        self.assertEqual(differential_report(1, 0.2, 0.5)["cyclic_bell_fidelity"], "1/2")


if __name__ == "__main__":
    unittest.main()
