"""Exact channel checks for the finite saddle construction."""

import unittest
from fractions import Fraction

from quantum.saddle_qec import (
    CODEWORDS,
    FLIP_MASKS,
    apply_channel,
    encode,
    flip_channel,
    logical_channel,
    recovery,
    report,
)


class SaddleQECTest(unittest.TestCase):
    def test_minimal_exact_matrix_units(self):
        recovery_channel = recovery()
        for mask in FLIP_MASKS:
            for row in range(2):
                for column in range(2):
                    with self.subTest(mask=mask, row=row, column=column):
                        unit = {(row, column): 1}
                        noisy = apply_channel(encode(unit), flip_channel({mask: 1}))
                        self.assertEqual(apply_channel(noisy, recovery_channel), unit)

    def test_cptp_and_knill_laflamme(self):
        # Each injective Kraus map contributes a diagonal K†K on its domain.
        for flat in (False, True):
            for decoder in ("saddle", "standard", "projection", "measured"):
                with self.subTest(flat=flat, decoder=decoder):
                    operators = recovery(decoder, flat=flat)
                    for _, mapping in operators:
                        self.assertEqual(len(set(mapping.values())), len(mapping))
                    for basis in range(8):
                        self.assertEqual(sum(w for w, m in operators if basis in m), 1)

        self.assertEqual(len(set(CODEWORDS)), 2)  # V†V = I
        for first in FLIP_MASKS:
            for second in FLIP_MASKS:
                for row, left in enumerate(CODEWORDS):
                    for column, right in enumerate(CODEWORDS):
                        self.assertEqual(
                            int((left ^ first) == (right ^ second)),
                            int(first == second and row == column),
                        )

    def test_arbitrary_phase_mixed_state_and_baseline_equivalence(self):
        # Exact dyadic entries, including a mixed state with nonzero complex coherence.
        states = (
            {(0, 0): 0.5, (0, 1): (1 - 1j) / 4, (1, 0): (1 + 1j) / 4, (1, 1): 0.5},
            {(0, 0): 0.5, (0, 1): -0.5j, (1, 0): 0.5j, (1, 1): 0.5},
            {(0, 0): 0.25, (1, 1): 0.75},
        )
        probs = {0: Fraction(1, 2), 1: Fraction(1, 8),
                 2: Fraction(1, 8), 4: Fraction(1, 4)}
        for state in states:
            self.assertEqual(logical_channel(state, probs), state)
        # Compare all 64 physical matrix units, including cross-sector coherence.
        for row in range(8):
            for column in range(8):
                unit = {(row, column): 1}
                exact = apply_channel(unit, recovery())
                self.assertEqual(exact, apply_channel(unit, recovery("standard")))
                self.assertEqual(exact, apply_channel(unit, recovery(flat=True)))

    def test_bell_controls(self):
        values = report()
        self.assertEqual(values["saddle"], 1)
        self.assertEqual(values["standard"], 1)
        self.assertEqual(values["flat"], 1)
        self.assertEqual(values["uncoded"], Fraction(7, 8))
        self.assertEqual(values["projection"], Fraction(5, 8))
        self.assertEqual(values["measured"], Fraction(1, 2))
        self.assertEqual(values["double_flip"], 0)
        self.assertEqual(values["phase_flip"], 0)

    def test_invalid_noise(self):
        for probabilities in ({}, {0: 2, 1: -1}, {0: Fraction(1, 2)}, {8: 1}):
            with self.subTest(probabilities=probabilities), self.assertRaises(ValueError):
                flip_channel(probabilities)


if __name__ == "__main__":
    unittest.main()
