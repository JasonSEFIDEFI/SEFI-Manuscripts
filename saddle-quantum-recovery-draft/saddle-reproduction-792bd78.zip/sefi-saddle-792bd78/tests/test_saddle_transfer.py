"""Check held-out calibration transfer and a mismatch invisible to one shot."""

import unittest

from quantum.saddle_transfer import CALIBRATION_PAIRS, TEST_PAIRS, report


class SaddleTransferTest(unittest.TestCase):
    def test_calibration_pairs_are_held_out(self):
        self.assertTrue(set(CALIBRATION_PAIRS).isdisjoint(TEST_PAIRS))

    def test_aligned_one_shot_transfer(self):
        aligned = report()["aligned"]
        self.assertEqual(aligned["saddle_one_shot"], aligned["conventional_same_shape_one_shot"])
        self.assertEqual(aligned["saddle_one_shot"]["mean_bell_fidelity"], 1)
        independent = aligned["conventional_independent_four_shots"]
        self.assertEqual(independent["mean_bell_fidelity"], 1)
        self.assertEqual(independent["calibration_shots"], 4)
        self.assertLess(aligned["conventional_independent_one_shot"]["mean_bell_fidelity"], 1)

    def test_cross_coupled_field_requires_more_information(self):
        mismatched = report()["cross_coupled"]
        self.assertEqual(mismatched["saddle_one_shot"],
                         mismatched["conventional_same_shape_one_shot"])
        self.assertLess(mismatched["saddle_one_shot"]["mean_bell_fidelity"], 1)
        self.assertEqual(mismatched["conventional_independent_four_shots"]["mean_bell_fidelity"], 1)
