"""Verify the calibration ablation and its off-model control."""

from fractions import Fraction
import unittest

from quantum.saddle_calibration import CALIBRATION, HELD_OUT, compare, saddle_feature


class SaddleCalibrationTest(unittest.TestCase):
    def test_surface_feature_and_data_separation(self):
        self.assertTrue(set(CALIBRATION).isdisjoint(HELD_OUT))
        for dx, dy in HELD_OUT:
            self.assertEqual(saddle_feature(dx, dy), 2 * (dx + dy))

    def test_aligned_noise_saves_one_axis_measurement(self):
        results = compare(0)
        self.assertEqual(results["saddle"], results["linear_shared_slope"])
        self.assertEqual(results["saddle"]["mean_bell_fidelity"], 1)
        self.assertEqual(results["linear_independent_slopes_two_axes"]["mean_bell_fidelity"], 1)
        self.assertLess(results["linear_independent_slopes_one_axis"]["mean_bell_fidelity"], 1)

    def test_wrong_geometry_prior_can_hurt(self):
        results = compare(Fraction(3, 4))
        self.assertEqual(results["saddle"], results["linear_shared_slope"])
        self.assertLess(results["saddle"]["mean_bell_fidelity"],
                        results["linear_independent_slopes_one_axis"]["mean_bell_fidelity"])
        self.assertEqual(results["linear_independent_slopes_two_axes"]["mean_bell_fidelity"], 1)


if __name__ == "__main__":
    unittest.main()
