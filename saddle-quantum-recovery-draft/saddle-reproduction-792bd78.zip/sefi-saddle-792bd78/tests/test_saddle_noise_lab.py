"""Check that the explanation traces the same residual used for scoring."""

import unittest

from quantum.saddle_displacement import gaussian_entanglement_fidelity
from quantum.saddle_noise_lab import SIGMA, explain


class SaddleNoiseLabTest(unittest.TestCase):
    def test_equal_saddle_height_changes_can_hide_differential_drift(self):
        trace = explain(gain=1)
        self.assertEqual(trace["saddle_height_change_at_each_location"], [4, 4])
        self.assertEqual(trace["predicted_differential_vertical_shift"], 0)
        residual = trace["actual_shift_difference_for_scoring_only"]
        self.assertNotEqual(residual, 0)
        self.assertEqual(trace["residual_after_correction"], residual)
        self.assertEqual(trace["bell_fidelity"], gaussian_entanglement_fidelity(SIGMA, residual))
